from D1mini import *
display.fill(0)
display.text('Hello,', 10, 10)
display.text('World!', 10, 20)
display.show()
